"""Stage 2: Fock-resolved channels -> thermal recombination -> compare with Hirai.

  1. spline check: drop every other dense n, interpolate, compare with the exact chi_n
  2. thermal: chi_th(nbar) = sum_n P_th(n) chi_n   vs Hirai's exact chi (all 81 nbar)
       - "matched": thermal P truncated at Hirai's phonon_dim (same truncation as Hirai)
       - "converged": tail < 1e-12
  3. variance at fixed mean: negative-binomial P(n) with Var = nbar + nbar^2/k
       (k -> inf Poisson, k = 1 thermal, k < 1 super-thermal)
Figures + CSV go to results/.

usage:
  uv run python scripts/compare_fock_thermal.py --table results/fock_tau100us.npz \
      --hirai ../exact_full_chi/full_chi_components_long.csv --index ../exact_full_chi/latest_run_index.csv
"""

from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy.stats import nbinom

from msgate import LABELS
from msgate.fock import FockTable
from msgate.model import thermal_probs
from msgate.pauli import to_hirai_convention

SERIES = ["#257de0", "#f47230", "#00b894", "#f2a600", "#ee7fac"]   # fixed categorical order
MAIN = ["XX", "XI", "IZ", "IY"]


def load_hirai_long(path: Path) -> dict[float, np.ndarray]:
    chis = defaultdict(lambda: np.zeros((16, 16), complex))
    with open(path) as f:
        for r in csv.DictReader(f):
            n = float(r["n_bar"])
            i, j = LABELS.index(r["row_pauli"]), LABELS.index(r["column_pauli"])
            v = float(r["real"]) + 1j * float(r["imag"])
            chis[n][i, j] = v
            chis[n][j, i] = np.conj(v)
    return dict(sorted(chis.items()))


def load_dims(path: Path) -> dict[float, int]:
    with open(path) as f:
        return {float(r["n_bar"]): int(r["phonon_dim"]) for r in csv.DictReader(f)}


def nb_probs(mean: float, k: float, nmax: int) -> np.ndarray:
    n = np.arange(nmax)
    if np.isinf(k):
        from scipy.stats import poisson
        p = poisson.pmf(n, mean)
    else:
        p = nbinom.pmf(n, k, k / (k + mean))
    return p / p.sum()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--table", type=Path, default=Path("results/fock_tau100us.npz"))
    ap.add_argument("--hirai", type=Path, default=Path("../exact_full_chi/full_chi_components_long.csv"))
    ap.add_argument("--index", type=Path, default=Path("../exact_full_chi/latest_run_index.csv"))
    ap.add_argument("--outdir", type=Path, default=Path("results"))
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    tab = FockTable.load(args.table)
    ns = tab.ns
    nmax_grid = int(ns.max())
    dense = ns[np.r_[True, np.diff(ns) == 1]]
    print(f"Fock table: {len(ns)} states, dense 0..{dense.max()}, max n {nmax_grid}")

    # ---- 1. spline check ---------------------------------------------------
    keep = np.ones(len(ns), bool)
    keep[1:int(dense.max()):2] = False
    sub = FockTable(tab.params, ns[keep], tab.chis[keep])
    held = ns[~keep]
    err = np.abs(sub.chi_at(held) - tab.chis[~keep]).max(axis=(1, 2))
    print(f"[spline] max |chi_interp - chi_exact| on held-out dense n: {err.max():.2e}")

    # ---- 2. thermal vs Hirai -----------------------------------------------
    hirai = load_hirai_long(args.hirai)
    dims = load_dims(args.index)
    rows = []
    for nbar, chi_h in hirai.items():
        dim_h = dims[nbar]
        p_m = thermal_probs(nbar, dim_h)
        chi_m = to_hirai_convention(tab.combine(p_m))
        chi_c = to_hirai_convention(tab.thermal(nbar))
        need = int(np.ceil(np.log(1e-12) / np.log(nbar / (nbar + 1)))) if nbar > 0 else 1
        row = dict(n_bar=nbar, hirai_dim=dim_h, n_needed_1e12=need,
                   max_dchi_matched=np.abs(chi_m - chi_h).max(),
                   max_dchi_converged=np.abs(chi_c - chi_h).max())
        for lab in MAIN:
            k = LABELS.index(lab)
            row[f"p{lab}_hirai"] = chi_h[k, k].real
            row[f"p{lab}_fock_matched"] = chi_m[k, k].real
            row[f"p{lab}_fock_converged"] = chi_c[k, k].real
        rows.append(row)
    with open(args.outdir / "fock_vs_hirai.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print(f"{'nbar':>6} {'dim_h':>5} {'|dchi| matched':>14} {'|dchi| conv':>12} {'pXX hirai':>10} {'pXX conv':>10}")
    for r in rows:
        if r["n_bar"] in (0.01, 0.5, 1, 2, 4, 8, 12, 16, 20):
            print(f"{r['n_bar']:6g} {r['hirai_dim']:5d} {r['max_dchi_matched']:14.2e} "
                  f"{r['max_dchi_converged']:12.2e} {r['pXX_hirai']:10.4e} {r['pXX_fock_converged']:10.4e}")

    # ---- 3. variance at fixed mean -----------------------------------------
    # only use P(n) that live (to < 1e-6) inside the computed grid: no extrapolation
    means = np.linspace(0.0, 10.0, 41)[1:]
    ks = [np.inf, 4.0, 1.0, 0.5]
    var_rows = []
    curves = {}
    for k in ks:
        cx = []
        for m in means:
            p_full = nb_probs(m, k, 20 * nmax_grid)
            tail = p_full[nmax_grid + 1:].sum()
            if tail > 1e-6:
                cx.append([np.nan] * len(MAIN))
                continue
            chi = tab.combine(p_full[:nmax_grid + 1])
            cx.append([chi[LABELS.index(l), LABELS.index(l)].real for l in MAIN])
            var_rows.append(dict(k=k, mean=m, var=m + (0 if np.isinf(k) else m * m / k), tail=tail,
                                 **{f"p{l}": v for l, v in zip(MAIN, cx[-1])}))
        curves[k] = np.array(cx)
    with open(args.outdir / "variance_sensitivity.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(var_rows[0]))
        w.writeheader()
        w.writerows(var_rows)

    # ---- figures -------------------------------------------------------------
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False,
                         "axes.grid": True, "grid.color": "#e6e6e6", "grid.linewidth": 0.8,
                         "lines.linewidth": 2, "font.size": 10})

    # (a) Fock-resolved probabilities
    fig, ax = plt.subplots(figsize=(6.4, 4.2))
    for c, lab in zip(SERIES, MAIN):
        k = LABELS.index(lab)
        ax.plot(ns, tab.chis[:, k, k].real, color=c, label=lab)
    ax.set_yscale("log")
    ax.set_xlabel("Fock number n")
    ax.set_ylabel("Pauli error probability (MS frame)")
    ax.set_title(f"Fock-resolved MS error, tau = {tab.params.tau*1e6:g} us")
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(args.outdir / "fock_resolved_probs.png", dpi=200)

    # (b) thermal recombination vs Hirai (+ residual)
    nb = np.array([r["n_bar"] for r in rows])
    fig, (ax, axr) = plt.subplots(2, 1, figsize=(6.4, 5.6), sharex=True,
                                  gridspec_kw={"height_ratios": [3, 1.3]})
    for c, lab in zip(SERIES, MAIN):
        ax.plot(nb, [r[f"p{lab}_fock_converged"] for r in rows], color=c, label=f"{lab}  sum_n P_th(n) chi_n")
        ax.plot(nb, [r[f"p{lab}_hirai"] for r in rows], "o", ms=3.5, mfc="white", mec=c, mew=1.2)
    ax.set_yscale("log")
    ax.set_ylabel("Pauli error probability")
    ax.set_title("Thermal channel from Fock-resolved channels (lines) vs Hirai (circles)")
    ax.legend(frameon=False, fontsize=8)
    axr.semilogy(nb, [r["max_dchi_matched"] for r in rows], color=SERIES[0], label="same truncation as Hirai")
    axr.semilogy(nb, [r["max_dchi_converged"] for r in rows], color=SERIES[1], label="converged tail")
    axr.set_ylabel("max |dchi|")
    axr.set_xlabel("mean phonon number nbar")
    axr.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(args.outdir / "thermal_from_fock_vs_hirai.png", dpi=200)

    # (c) variance sensitivity
    names = {np.inf: "Poisson (Var = n)", 4.0: "NB k=4", 1.0: "thermal (Var = n + n^2)",
             0.5: "NB k=0.5 (super-thermal)"}
    fig, axs = plt.subplots(1, 2, figsize=(9.6, 3.8))
    for ax, lab in zip(axs, ["XX", "XI"]):
        j = MAIN.index(lab)
        for c, k in zip(SERIES, ks):
            ax.plot(means, curves[k][:, j], color=c, label=names[k])
        ax.set_xlabel("mean phonon number")
        ax.set_ylabel(f"p_{lab}")
        ax.set_title(f"p_{lab} at fixed mean, varying variance")
    axs[0].legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(args.outdir / "variance_sensitivity.png", dpi=200)
    print(f"figures -> {args.outdir}")


if __name__ == "__main__":
    main()
