"""Compute Fock-resolved error channels chi_n and save them as a FockTable (.npz).

usage:
  uv run python scripts/fock_channels.py --dense 80 --sparse 85:200:5 210:400:10 --workers 4
  uv run python scripts/fock_channels.py --tau 59e-6 --out results/fock_tau59us.npz
"""

from __future__ import annotations

import argparse
from pathlib import Path

from msgate import MSParams, SolverOptions
from msgate.fock import FockTable


def parse_range(s: str) -> list[int]:
    a, b, c = (int(x) for x in s.split(":"))
    return list(range(a, b + 1, c))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tau", type=float, default=100e-6)
    ap.add_argument("--dense", type=int, default=80, help="all n = 0..dense")
    ap.add_argument("--sparse", nargs="*", default=["85:200:5", "210:400:10"],
                    help="start:stop:step ranges (inclusive)")
    ap.add_argument("--margin", type=int, default=12)
    ap.add_argument("--workers", type=int, default=1)
    ap.add_argument("--out", type=Path, default=None)
    args = ap.parse_args()

    prm = MSParams(tau=args.tau)
    ns = set(range(args.dense + 1))
    for s in args.sparse:
        ns |= set(parse_range(s))
    out = args.out or Path(f"results/fock_tau{args.tau*1e6:g}us.npz")
    out.parent.mkdir(parents=True, exist_ok=True)
    print(f"tau = {prm.tau*1e6:g} us, {len(ns)} Fock states, max n = {max(ns)} -> {out}")
    tab = FockTable.compute(prm, sorted(ns), SolverOptions(), margin=args.margin,
                            workers=args.workers, checkpoint=out)
    print(f"saved {out}  (total solver time {tab.elapsed.sum():.0f}s)")


if __name__ == "__main__":
    main()
