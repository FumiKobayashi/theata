"""Compare msgate against Hirai's exact error chi matrices.

usage:
  uv run python scripts/validate_hirai.py --chi-dir ../exact_full_chi --nbar 0.01 1 4
  uv run python scripts/validate_hirai.py --chi-dir ../exact_full_chi --nbar 2 --dim-factor 1.5
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

from msgate import LABELS, MSParams, SolverOptions, thermal_channel
from msgate.pauli import to_hirai_convention


def nbar_tag(n: float) -> str:
    s = f"{n:g}" if n != int(n) else f"{n:.1f}"
    return s.replace(".", "p")


def load_hirai(chi_dir: Path, nbar: float):
    f = chi_dir / f"error_chi_nbar_{nbar_tag(nbar)}.npz"
    d = np.load(f)
    labels = [str(x) for x in d["pauli_labels"]]
    assert labels == LABELS, labels
    meta = json.loads(str(d["metadata_json"]))
    return d["chi_trace_normalized"], meta


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--chi-dir", type=Path, default=Path("../exact_full_chi"))
    ap.add_argument("--nbar", type=float, nargs="+", default=[0.01, 1.0, 4.0])
    ap.add_argument("--tau", type=float, default=100e-6)
    ap.add_argument("--dim-factor", type=float, default=1.0,
                    help="phonon dim = factor * Hirai's dim (convergence check)")
    ap.add_argument("--coeff-mode", default="interp", choices=["interp", "exact"])
    ap.add_argument("--out", type=Path, default=Path("results/validate_hirai.csv"))
    args = ap.parse_args()

    prm = MSParams(tau=args.tau)
    opts = SolverOptions(coeff_mode=args.coeff_mode)
    print(f"A/2pi = {prm.A_phys_hz:.1f} Hz, delta/2pi = {prm.delta_phys_hz:.1f} Hz, tau = {prm.tau*1e6:.1f} us")

    rows = []
    hdr = f"{'nbar':>6} {'dim':>5} {'max|dchi|':>10} {'max|dp|':>10} {'pXX ours':>11} {'pXX hirai':>11} {'pXI ours':>11} {'pXI hirai':>11} {'t[s]':>7}"
    print(hdr)
    for nbar in args.nbar:
        chi_h, meta = load_hirai(args.chi_dir, nbar)
        dim = int(round(meta["phonon_dim"] * args.dim_factor))
        r = thermal_channel(prm, nbar, dim=dim, opts=opts)
        chi = to_hirai_convention(r.chi_err)  # Y-sign convention of Hirai's files
        dchi = np.abs(chi - chi_h).max()
        dp = np.abs(np.diag(chi).real - np.diag(chi_h).real).max()
        ixx, ixi = LABELS.index("XX"), LABELS.index("XI")
        row = dict(n_bar=nbar, dim=dim, max_abs_dchi=dchi, max_abs_dp=dp,
                   pXX=chi[ixx, ixx].real, pXX_hirai=chi_h[ixx, ixx].real,
                   pXI=chi[ixi, ixi].real, pXI_hirai=chi_h[ixi, ixi].real,
                   chi_II_XX=complex(chi[0, ixx]), chi_II_XX_hirai=complex(chi_h[0, ixx]),
                   elapsed=r.elapsed)
        rows.append(row)
        print(f"{nbar:6g} {dim:5d} {dchi:10.2e} {dp:10.2e} {row['pXX']:11.4e} {row['pXX_hirai']:11.4e} "
              f"{row['pXI']:11.4e} {row['pXI_hirai']:11.4e} {r.elapsed:7.1f}")

    args.out.parent.mkdir(parents=True, exist_ok=True)
    with open(args.out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print(f"-> {args.out}")


if __name__ == "__main__":
    main()
