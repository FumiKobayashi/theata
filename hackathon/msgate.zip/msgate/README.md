# msgate

熱的な運動状態にある Mølmer–Sørensen gate の Lindblad master 方程式を解き、
2-qubit のエラーチャネル（χ 行列・Pauli twirl 確率）を出すパッケージ。
平井さんの基準モデルをそのまま実装している。

## セットアップ

```zsh
cd msgate
uv sync            # .venv 作成 + 依存 (numpy, scipy, pytest)
uv run pytest      # 基本テスト
```

## モデル（デフォルト = 平井さんの設定）

時間は τ 単位、δ = 2πK、A = δ/(4√K)（K=1 で A/δ = 1/4）。

$$H = A\,S_x\,(B e^{-i\delta t} + B^\dagger e^{i\delta t}),\quad S_x=X_1+X_2,\quad B = a - \tfrac{\eta^2}{2}(N+1)a$$

| 機構 | ジャンプ演算子 | デフォルト |
|---|---|---|
| heating | √Γh a, √Γh a† | Γh = 10 /s（dn̄/dt = 10 quanta/s） |
| motional dephasing | √Γm N | Γm = 18 /s |
| spin dephasing | √(Γs/2) Z_j | Γs = 1/0.3 /s |
| Rayleigh | √Γ_Ray Z_j | 3 /s |
| Raman | √(Γ_Ram/2) σ_j^± | 1 /s |

- `MSParams(tau=100e-6, K=1, eta=0.1, ...)`：`tau` を変えればゲート時間を変えられる（例 `MSParams(tau=59e-6)`）。
- 規約：U_ideal = exp(+iπXX/4)、テンソル順 (q1, q2)、ラベル左 = q1、E_err = E_actual ∘ E_ideal⁻¹、
  χ は E(ρ) = Σ χ_ij P_i ρ P_j（Tr χ = 1）。

## 使い方

```python
from msgate import MSParams, SolverOptions, thermal_channel, simulate_channel, fock_probs

r = thermal_channel(MSParams(), n_bar=1.0, dim=40)
r.chi_err          # 16x16 complex
r.probs            # {"II": ..., "IX": ..., ...}
r.avg_gate_infidelity

# 任意の位相平均された運動状態 diag(p_n)（Fock 状態、非熱分布など）
r0 = simulate_channel(MSParams(), fock_probs(3, dim=40))
```

## 平井さんデータとの照合

```zsh
uv run python scripts/validate_hirai.py --chi-dir ../exact_full_chi --nbar 0.01 1 4
```

`--coeff-mode interp`（デフォルト）は平井さんと同じく e^{-iδt} を 500 点で線形補間する。
`--dim-factor 1.5` で Fock 打ち切りの収束を確認できる。

## Fock 状態ごとのチャネル（stage 2）

初期運動状態は Fock 基底で対角なので E[P] = Σ_n P(n) E_n。

```zsh
uv run python scripts/fock_channels.py --workers 4            # n=0..80 全部 + 85..400 疎, results/fock_tau100us.npz
uv run python scripts/compare_fock_thermal.py                 # 平井さん χ との比較 + 分散感度の図
```

```python
from msgate.fock import FockTable
tab = FockTable.load("results/fock_tau100us.npz")
chi = tab.combine(P)          # 任意の P(n)（疎な n は cubic spline 補間、範囲外は外挿しない）
chi_th = tab.thermal(5.0)
```

- `fock_channels.py` は 1 状態ごとに checkpoint を保存し、再実行すると続きから計算する。
- 注意：平井モデルの結合 √n(1-η²n/2) は n = 2/η² = 200 でゼロになり、それ以上で符号反転する（本来の
  Laguerre 因子の最初のゼロは n≈370）。n ≳ 100 の E_n はモデルの適用範囲外。

## 実装メモ

- スピンを x 基底で持つと S_x は対角、全スピンジャンプは monomial 行列になる。
  入力 |a⟩⟨b| は a⊕b が保存される 4 ブロックにしか広がらないので、4 ブロック × 4 入力のバッチで解く。
- 運動演算子は配列シフトで作用させる（行列積なし）。1 RHS あたり O(N²)。
