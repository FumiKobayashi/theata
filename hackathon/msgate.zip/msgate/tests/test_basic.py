import numpy as np

from msgate import MSParams, SolverOptions, thermal_channel, LABELS
from msgate.pauli import (PAULIS, chi_from_superop, superop_from_chi,
                          superop_from_unitary, ms_ideal_unitary)

OPTS = SolverOptions(rtol=1e-10, atol=1e-12)


def test_chi_roundtrip_and_pauli_unitary():
    for k, p in enumerate(PAULIS):
        chi = chi_from_superop(superop_from_unitary(p))
        expect = np.zeros((16, 16))
        expect[k, k] = 1.0
        assert np.allclose(chi, expect)
    rng = np.random.default_rng(0)
    m = rng.normal(size=(16, 16)) + 1j * rng.normal(size=(16, 16))
    assert np.allclose(superop_from_chi(chi_from_superop(m)), m)


def test_noiseless_lamb_dicke_gate_is_ideal():
    """eta -> 0, no dissipation: closed loop, exp(+i pi/4 XX) independent of nbar."""
    prm = MSParams(dw_correction=False).noiseless()
    for nbar in (0.0, 2.0):
        r = thermal_channel(prm, nbar, dim=80, opts=OPTS)
        assert r.process_infidelity < 1e-8, (nbar, r.process_infidelity)


def test_trace_preserving():
    r = thermal_channel(MSParams(), 0.5, dim=25, opts=OPTS)
    assert abs(np.trace(r.chi_err) - 1.0) < 1e-9
    assert set(r.probs) == set(LABELS)


def test_spin_dephasing_only_matches_analytic():
    """Spin dephasing alone: avg gate infidelity = 0.8 * Gamma_s * tau (to first order)."""
    prm = MSParams(dw_correction=False).noiseless().with_(gamma_sdeph=1 / 0.3)
    r = thermal_channel(prm, 0.01, dim=20, opts=OPTS)
    assert abs(r.avg_gate_infidelity / (0.8 * prm.gamma_sdeph * prm.tau) - 1) < 1e-2


def test_fock_recombination_equals_thermal():
    """Linearity: sum_n P_th(n) chi_n == chi for the thermal initial state."""
    from msgate import thermal_probs
    from msgate.fock import FockTable
    prm = MSParams()
    nbar, dim = 0.2, 14
    tab = FockTable.compute(prm, range(dim), OPTS, margin=12, verbose=False)
    chi_fock = tab.combine(thermal_probs(nbar, dim))
    chi_th = thermal_channel(prm, nbar, dim=dim + 12, opts=OPTS).chi_err
    assert np.abs(chi_fock - chi_th).max() < 1e-7
