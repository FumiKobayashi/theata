"""Lindblad simulation of the MS gate (spin x motion) and process reconstruction.

Hamiltonian (Hirai model, motional RWA, time in units of tau):

    H = A S_x (B e^{-i delta t} + B^dag e^{+i delta t}),   S_x = X_1 + X_2,
    B = a - (eta^2/2) (N+1) a            ( <n-1|B|n> = sqrt(n) (1 - eta^2 n / 2) )

Implementation notes
--------------------
* Spin is written in the x basis, where S_x is diagonal (s = 2, 0, 0, -2) and every
  spin jump operator (X_j, Y_j, Z_j) is a monomial matrix. The density matrix is kept as
  4x4 blocks of N x N motional operators.
* Spin jumps map block (a, b) -> (a^f, b^f) for a flip mask f, so a^b is conserved.
  An input |a0><b0| therefore only ever populates the 4 blocks with a^b = a0^b0
  ("orbit" c = a0^b0). We evolve each orbit with a batch of 4 inputs.
* Raman: sum_{+-} D[sqrt(G/2) sigma^{+-}] = (G/4) (D[X] + D[Y]) exactly.
* All motional operators act by array shifts (no matrix products), cost O(N^2) per block.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np
from scipy.integrate import solve_ivp

from .params import MSParams, SolverOptions, default_phonon_dim
from .pauli import (H2, PAULIS, LABELS, chi_from_superop, ms_ideal_unitary,
                    pauli_probs, superop_from_unitary)

# x-basis index a = 2*bit1 + bit2, bit 0 <-> |+>, bit 1 <-> |->
_S_X = np.array([2.0, 0.0, 0.0, -2.0])


# ---------------------------------------------------------------------------
# motional state helpers
# ---------------------------------------------------------------------------
def thermal_probs(n_bar: float, dim: int) -> np.ndarray:
    """Truncated & renormalised thermal occupation probabilities."""
    n = np.arange(dim)
    if n_bar <= 0:
        p = (n == 0).astype(float)
    else:
        q = n_bar / (n_bar + 1.0)
        p = (1.0 - q) * q ** n
    return p / p.sum()


def fock_probs(n: int, dim: int) -> np.ndarray:
    p = np.zeros(dim)
    p[n] = 1.0
    return p


# ---------------------------------------------------------------------------
# spin jump bookkeeping in the x basis
# ---------------------------------------------------------------------------
def _monomial(p_x: np.ndarray):
    """For a monomial 4x4 matrix return (dest, coeff) with P|a> = coeff[a] |dest[a]>."""
    dest = np.argmax(np.abs(p_x), axis=0)
    coeff = p_x[dest, np.arange(4)]
    assert np.allclose(np.abs(coeff), 1.0)
    return dest, coeff


def _spin_jumps(prm: MSParams):
    """List of (rate, two-qubit Pauli label) with D = rate (P rho P - rho)."""
    gz = prm.gamma_sdeph / 2.0 + prm.gamma_ray
    gxy = prm.gamma_ram / 4.0
    jumps = []
    for q in (0, 1):
        lab = lambda s: (s + "I") if q == 0 else ("I" + s)
        jumps += [(gz, lab("Z")), (gxy, lab("X")), (gxy, lab("Y"))]
    return [(g * prm.tau, l) for g, l in jumps if g > 0]


@dataclass
class _Orbit:
    """Precomputed data for one orbit c (blocks (a, a^c), a = 0..3)."""
    c: int
    sa: np.ndarray
    sb: np.ndarray
    jumps: list = field(default_factory=list)   # (rate, dest[4], coeff[4])
    mix: np.ndarray | None = None               # 4x4: d rho_a/dt += sum_b mix[a, b] rho_b


def _build_orbits(prm: MSParams) -> list[_Orbit]:
    jumps = []
    for rate, lab in _spin_jumps(prm):
        p_x = H2 @ PAULIS[LABELS.index(lab)] @ H2
        jumps.append((rate, *_monomial(p_x)))
    orbits = []
    a = np.arange(4)
    for c in range(4):
        ob = _Orbit(c=c, sa=_S_X[a], sb=_S_X[a ^ c])
        for rate, dest, coeff in jumps:
            # (P rho P^dag)_{dest[a], dest[a^c]} += coeff[a] conj(coeff[a^c]) rho_{a, a^c}
            assert np.all(dest[a] ^ dest[a ^ c] == c)
            ph = coeff[a] * coeff[a ^ c].conj()
            ob.jumps.append((rate, dest, ph))
        if ob.jumps:
            mix = np.zeros((4, 4), dtype=complex)
            for rate, dest, ph in ob.jumps:
                mix[dest, a] += rate * ph
                mix[a, a] -= rate
            ob.mix = mix
        orbits.append(ob)
    return orbits


# ---------------------------------------------------------------------------
# right-hand side
# ---------------------------------------------------------------------------
class _RHS:
    def __init__(self, prm: MSParams, dim: int, opts: SolverOptions, n_offset: int = 0):
        self.prm, self.dim, self.opts = prm, dim, opts
        # Fock window {n_offset, ..., n_offset + dim - 1}
        n = n_offset + np.arange(dim, dtype=float)
        k = n[1:]                                          # matrix element <k-1|B|k>
        b = np.sqrt(k)
        if prm.dw_correction:
            b = b * (1.0 - prm.eta ** 2 * k / 2.0)
        self.b = b                                         # length dim-1
        self.sq = np.sqrt(k)                               # a: <k-1|a|k> = sqrt(k)
        self.sqsq = np.outer(self.sq, self.sq)

        gh = prm.gamma_heat * prm.tau
        gm = prm.gamma_mdeph * prm.tau
        # products of the *truncated* a, a^dag (keeps the map trace preserving)
        ada = n.copy()
        ada[0] = 0.0 if n_offset > 0 else ada[0]
        aad = n + 1.0
        aad[-1] = 0.0
        dsum = ada + aad
        self.gh = gh
        self.decay = (-0.5 * gh * (dsum[:, None] + dsum[None, :])
                      - 0.5 * gm * (n[:, None] - n[None, :]) ** 2)
        self.A = prm.A
        self.delta = prm.delta
        if opts.coeff_mode == "interp":
            self.tg = np.linspace(0.0, 1.0, opts.n_interp)
            fg = np.exp(-1j * self.delta * self.tg)
            self.fr, self.fi = fg.real, fg.imag
        elif opts.coeff_mode != "exact":
            raise ValueError(opts.coeff_mode)
        self.orbit: _Orbit | None = None

    def coeff(self, t: float) -> complex:
        if self.opts.coeff_mode == "exact":
            return np.exp(-1j * self.delta * t)
        return np.interp(t, self.tg, self.fr) + 1j * np.interp(t, self.tg, self.fi)

    def __call__(self, t, y):
        ob = self.orbit
        N = self.dim
        rho = y.reshape(-1, 4, N, N)            # (batch, block a, m, n)
        f = self.coeff(t)
        fc = np.conj(f)
        b = self.b

        # C rho with C = f B + f* B^dag
        c_rho = np.zeros_like(rho)
        c_rho[..., :-1, :] += f * b[:, None] * rho[..., 1:, :]
        c_rho[..., 1:, :] += fc * b[:, None] * rho[..., :-1, :]
        # rho C
        rho_c = np.zeros_like(rho)
        rho_c[..., :, 1:] += f * rho[..., :, :-1] * b[None, :]
        rho_c[..., :, :-1] += fc * rho[..., :, 1:] * b[None, :]

        sa = ob.sa[None, :, None, None]
        sb = ob.sb[None, :, None, None]
        out = -1j * self.A * (sa * c_rho - sb * rho_c)

        # motional dissipators
        out += self.decay * rho
        if self.gh:
            out[..., :-1, :-1] += self.gh * self.sqsq * rho[..., 1:, 1:]   # a rho a^dag
            out[..., 1:, 1:] += self.gh * self.sqsq * rho[..., :-1, :-1]   # a^dag rho a

        # spin jumps  sum_P rate (P rho P - rho), pre-combined into a 4x4 block-mixing matrix
        if ob.mix is not None:
            out += np.einsum("ab,xbmn->xamn", ob.mix, rho, optimize=True)
        return out.ravel()


# ---------------------------------------------------------------------------
# channel
# ---------------------------------------------------------------------------
@dataclass
class ChannelResult:
    params: MSParams
    dim: int
    superop: np.ndarray          # actual spin channel (z basis, column-stacking)
    superop_err: np.ndarray      # E_err = E_actual o E_ideal^{-1}
    chi_err: np.ndarray          # 16x16, Tr = 1
    elapsed: float
    nfev: int

    @property
    def probs(self) -> dict[str, float]:
        return pauli_probs(self.chi_err)

    @property
    def process_infidelity(self) -> float:
        return 1.0 - float(self.chi_err[0, 0].real)

    @property
    def avg_gate_infidelity(self) -> float:
        d = 4
        return d / (d + 1) * self.process_infidelity


def simulate_channel(prm: MSParams, motional_probs: np.ndarray,
                     opts: SolverOptions = SolverOptions(), ideal_sign: int = +1,
                     n_offset: int = 0) -> ChannelResult:
    """Spin channel of the MS gate for a phase-averaged motional state diag(motional_probs).

    motional_probs[i] is the probability of Fock state n_offset + i (the simulation is done
    in that Fock window). The channel is linear in the initial motional state, so a
    Fock-resolved set of channels can be recombined for any P(n).
    """
    p = np.asarray(motional_probs, dtype=float)
    dim = p.size
    rhs = _RHS(prm, dim, opts, n_offset=n_offset)
    rho_m = np.diag(p).astype(complex)

    s_x = np.zeros((16, 16), dtype=complex)   # superop in the x basis
    t0 = time.perf_counter()
    nfev = 0
    for ob in _build_orbits(prm):
        rhs.orbit = ob
        y0 = np.zeros((4, 4, dim, dim), dtype=complex)   # (input a0, block a, m, n)
        for a0 in range(4):
            y0[a0, a0] = rho_m
        sol = solve_ivp(rhs, (0.0, 1.0), y0.ravel(), method=opts.method,
                        rtol=opts.rtol, atol=opts.atol, t_eval=[1.0])
        if not sol.success:
            raise RuntimeError(sol.message)
        nfev += sol.nfev
        y1 = sol.y[:, -1].reshape(4, 4, dim, dim)
        tr = np.trace(y1, axis1=2, axis2=3)               # (a0, a)
        c = ob.c
        for a0 in range(4):
            col = a0 + 4 * (a0 ^ c)                       # vec index of |a0><a0^c|
            for a in range(4):
                s_x[a + 4 * (a ^ c), col] = tr[a0, a]
    elapsed = time.perf_counter() - t0

    w = np.kron(H2, H2)               # vec(H2 rho H2) = (H2^T kron H2) vec(rho), H2 real symmetric
    s_z = w @ s_x @ w
    s_ideal = superop_from_unitary(ms_ideal_unitary(ideal_sign))
    s_err = s_z @ s_ideal.conj().T
    chi = chi_from_superop(s_err)
    return ChannelResult(prm, dim, s_z, s_err, chi, elapsed, nfev)


def thermal_channel(prm: MSParams, n_bar: float, dim: int | None = None,
                    opts: SolverOptions = SolverOptions(), **kw) -> ChannelResult:
    dim = dim or default_phonon_dim(n_bar)
    return simulate_channel(prm, thermal_probs(n_bar, dim), opts, **kw)
