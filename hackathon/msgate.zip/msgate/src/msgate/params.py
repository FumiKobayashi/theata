"""Physical parameters and solver options.

Default values reproduce Hirai's reference calculation:
  tau = 100 us, one loop (K=1), eta = 0.1,
  heating  sqrt(G_h) a, sqrt(G_h) a^dag      G_h  = 10 /s  (d nbar/dt = 10 quanta/s)
  motional dephasing sqrt(G_m) N             G_m  = 18 /s
  spin dephasing sqrt(G_s/2) Z_j             G_s  = 1/0.3 /s   (T2 = 0.3 s)
  Rayleigh sqrt(G_ray) Z_j                   G_ray = 3 /s
  Raman sqrt(G_ram/2) sigma_j^{+,-}          G_ram = 1 /s
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass, replace


@dataclass(frozen=True)
class MSParams:
    tau: float = 100e-6          # gate time [s]
    K: int = 1                   # number of phase-space loops
    eta: float = 0.1             # Lamb-Dicke parameter (enters only the O(eta^2) DW correction)
    dw_correction: bool = True   # B = a - eta^2/2 (N+1) a  (False -> B = a)
    amp_scale: float = 1.0       # A = amp_scale * A_ideal   (A_ideal = delta / (4 sqrt K))
    gamma_heat: float = 10.0     # [1/s]
    gamma_mdeph: float = 18.0    # [1/s]
    gamma_sdeph: float = 1.0 / 0.3
    gamma_ray: float = 3.0
    gamma_ram: float = 1.0

    # --- derived, dimensionless (time measured in units of tau) ---
    @property
    def delta(self) -> float:
        return 2.0 * math.pi * self.K

    @property
    def A(self) -> float:
        return self.amp_scale * self.delta / (4.0 * math.sqrt(self.K))

    @property
    def delta_phys_hz(self) -> float:
        """delta / 2pi in Hz."""
        return self.K / self.tau

    @property
    def A_phys_hz(self) -> float:
        """A / 2pi in Hz."""
        return self.A / (2.0 * math.pi * self.tau)

    def noiseless(self) -> "MSParams":
        return replace(self, gamma_heat=0.0, gamma_mdeph=0.0, gamma_sdeph=0.0,
                       gamma_ray=0.0, gamma_ram=0.0)

    def with_(self, **kw) -> "MSParams":
        return replace(self, **kw)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class SolverOptions:
    method: str = "DOP853"
    rtol: float = 1e-9
    atol: float = 1e-12
    coeff_mode: str = "exact"    # "exact": e^{-i delta t};  "interp": linear interp on n_interp points (Hirai)
    n_interp: int = 500


def default_phonon_dim(n_bar: float, tail: float = 1e-7, n_min: int = 20, margin: int = 10) -> int:
    """Fock cutoff such that the thermal tail P(n >= dim) < tail (plus a margin)."""
    if n_bar <= 0:
        return n_min
    q = n_bar / (n_bar + 1.0)
    n = math.ceil(math.log(tail) / math.log(q)) + margin
    return max(n_min, n)
