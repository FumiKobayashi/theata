"""Fock-resolved MS error channels E_n and their recombination for arbitrary P(n).

Because the initial motional state enters linearly and every distribution we care about
is phase averaged (diagonal in the Fock basis),

    E[P] = sum_n P(n) E_n ,        chi[P] = sum_n P(n) chi_n .

E_n is obtained by starting from |n><n| inside a Fock window around n: during the gate the
spin-dependent displacement is bounded by alpha_max = 2 |s|_max A / delta (= 1 for K=1),
so the population stays in  (sqrt(n) - alpha_max)^2 <= m <= (sqrt(n) + alpha_max)^2
up to exponentially small tails, covered by `margin`.
"""

from __future__ import annotations

import math
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from scipy.interpolate import CubicSpline

from .model import ChannelResult, fock_probs, simulate_channel, thermal_probs
from .params import MSParams, SolverOptions


def alpha_max(prm: MSParams) -> float:
    return 2.0 * 2.0 * prm.A / prm.delta


def coupling_factor(prm: MSParams, n: float) -> float:
    """|<n-1|B|n>| / sqrt(n) = |1 - eta^2 n / 2|  (the truncated DW model crosses zero
    at n = 2/eta^2 and grows again beyond it -- unphysical, but we follow the model)."""
    return abs(1.0 - prm.eta ** 2 * n / 2.0) if prm.dw_correction else 1.0


def fock_window(prm: MSParams, n: int, margin: int = 15) -> tuple[int, int]:
    """(offset, dim) of the Fock window used for the initial state |n>."""
    a0 = alpha_max(prm)
    hi0 = (math.sqrt(n) + a0) ** 2
    am = a0 * max(1.0, coupling_factor(prm, n), coupling_factor(prm, hi0 + margin))
    lo = max(0, math.floor((math.sqrt(n) - am) ** 2) - margin) if math.sqrt(n) > am else 0
    hi = math.ceil((math.sqrt(n) + am) ** 2) + margin
    return lo, hi - lo + 1


def fock_channel(prm: MSParams, n: int, opts: SolverOptions = SolverOptions(),
                 margin: int = 15) -> ChannelResult:
    lo, dim = fock_window(prm, n, margin)
    return simulate_channel(prm, fock_probs(n - lo, dim), opts, n_offset=lo)


def _worker(args):
    prm, n, opts, margin = args
    r = fock_channel(prm, n, opts, margin)
    return n, r.chi_err, r.dim, r.elapsed


@dataclass
class FockTable:
    """chi_n of the error channel for a (possibly sparse) set of Fock numbers."""
    params: MSParams
    ns: np.ndarray            # (M,) sorted Fock numbers
    chis: np.ndarray          # (M, 16, 16) complex
    dims: np.ndarray | None = None
    elapsed: np.ndarray | None = None

    # ---- construction / io -------------------------------------------------
    @classmethod
    def compute(cls, prm: MSParams, ns, opts: SolverOptions = SolverOptions(),
                margin: int = 15, workers: int = 1, verbose: bool = True,
                checkpoint: str | Path | None = None) -> "FockTable":
        """Compute chi_n for all n in ns. With `checkpoint`, the partial table is saved after
        every finished n and already-computed n are skipped on restart."""
        ns = sorted(int(n) for n in ns)
        out = {}
        if checkpoint is not None and Path(checkpoint).exists():
            old = cls.load(checkpoint)
            if old.params != prm:
                raise ValueError("checkpoint was computed with different parameters")
            for i, n in enumerate(old.ns):
                out[int(n)] = (old.chis[i], old.dims[i], old.elapsed[i])
            if verbose:
                print(f"  resumed {len(out)} states from {checkpoint}", flush=True)

        def build(keys):
            keys = sorted(keys)
            return cls(prm, np.array(keys), np.array([out[n][0] for n in keys]),
                       np.array([out[n][1] for n in keys]), np.array([out[n][2] for n in keys]))

        def done(n, chi, dim, el):
            out[n] = (chi, dim, el)
            if verbose:
                print(f"  n={n:4d} dim={dim:4d} {el:7.1f}s", flush=True)
            if checkpoint is not None:
                build(out).save(checkpoint)

        jobs = [(prm, n, opts, margin) for n in ns if n not in out]
        if workers > 1:
            with ProcessPoolExecutor(workers) as ex:
                for res in ex.map(_worker, jobs):
                    done(*res)
        else:
            for job in jobs:
                done(*_worker(job))
        return build(ns)

    def save(self, path: str | Path) -> None:
        import json
        np.savez(path, ns=self.ns, chis=self.chis, dims=self.dims, elapsed=self.elapsed,
                 params_json=json.dumps(self.params.to_dict()))

    @classmethod
    def load(cls, path: str | Path) -> "FockTable":
        import json
        d = np.load(path)
        prm = MSParams(**json.loads(str(d["params_json"])))
        return cls(prm, d["ns"], d["chis"], d["dims"], d["elapsed"])

    @classmethod
    def merge(cls, *tables: "FockTable") -> "FockTable":
        ns, chis, dims, els = {}, {}, {}, {}
        for t in tables:
            for i, n in enumerate(t.ns):
                ns[int(n)] = None
                chis[int(n)] = t.chis[i]
                dims[int(n)] = t.dims[i] if t.dims is not None else -1
                els[int(n)] = t.elapsed[i] if t.elapsed is not None else np.nan
        k = sorted(ns)
        return cls(tables[0].params, np.array(k), np.array([chis[n] for n in k]),
                   np.array([dims[n] for n in k]), np.array([els[n] for n in k]))

    # ---- evaluation --------------------------------------------------------
    def chi_at(self, n_query: np.ndarray) -> np.ndarray:
        """chi_n for arbitrary integer n (cubic spline in n where the grid is sparse;
        exact where n is on the grid). Beyond the last grid point: linear extrapolation."""
        n_query = np.asarray(n_query, dtype=float)
        flat = self.chis.reshape(len(self.ns), -1)
        cs_re = CubicSpline(self.ns, flat.real, axis=0, extrapolate=True)
        cs_im = CubicSpline(self.ns, flat.imag, axis=0, extrapolate=True)
        out = cs_re(n_query) + 1j * cs_im(n_query)
        return out.reshape(len(n_query), 16, 16)

    def combine(self, probs: np.ndarray, n_offset: int = 0) -> np.ndarray:
        """chi for the phase-averaged state with P(n_offset + i) = probs[i]."""
        probs = np.asarray(probs, dtype=float)
        n = n_offset + np.arange(probs.size)
        keep = probs > 1e-16
        return np.einsum("k,kij->ij", probs[keep], self.chi_at(n[keep]))

    def thermal(self, n_bar: float, dim: int | None = None, tail: float = 1e-12) -> np.ndarray:
        """Thermal chi. Default cutoff: tail < `tail`, capped at the last grid point
        (no extrapolation beyond the computed Fock states)."""
        if dim is None:
            q = n_bar / (n_bar + 1.0)
            dim = max(5, math.ceil(math.log(tail) / math.log(q))) if n_bar > 0 else 1
            dim = min(dim, int(self.ns.max()) + 1)
        return self.combine(thermal_probs(n_bar, dim))
