"""Two-qubit Pauli basis, superoperators and chi matrices.

Conventions (Hirai model):
  * tensor order (qubit1, qubit2); label "AB" = A on qubit1, B on qubit2
  * label order II, IX, ..., ZZ
  * vec = column stacking, so vec(A rho B) = (B^T kron A) vec(rho)
  * chi:  E(rho) = sum_ij chi_ij P_i rho P_j ,  Tr chi = 1 for a TP map
"""

from __future__ import annotations

import numpy as np

I2 = np.eye(2, dtype=complex)
X = np.array([[0, 1], [1, 0]], dtype=complex)
Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
Z = np.array([[1, 0], [0, -1]], dtype=complex)
SINGLE = {"I": I2, "X": X, "Y": Y, "Z": Z}

LABELS: list[str] = [a + b for a in "IXYZ" for b in "IXYZ"]
PAULIS: list[np.ndarray] = [np.kron(SINGLE[l[0]], SINGLE[l[1]]) for l in LABELS]

HADAMARD = np.array([[1, 1], [1, -1]], dtype=complex) / np.sqrt(2)
H2 = np.kron(HADAMARD, HADAMARD)  # z-basis <-> x-basis (real, symmetric, H2 @ H2 = 1)

# basis operators B_ij = P_j^T kron P_i with vec(P_i rho P_j) = B_ij vec(rho)
_CHI_BASIS = np.array([[np.kron(Pj.T, Pi) for Pj in PAULIS] for Pi in PAULIS])


def vec(m: np.ndarray) -> np.ndarray:
    return m.reshape(-1, order="F")


def unvec(v: np.ndarray, d: int = 4) -> np.ndarray:
    return v.reshape(d, d, order="F")


def superop_from_unitary(u: np.ndarray) -> np.ndarray:
    return np.kron(u.conj(), u)


def chi_from_superop(s: np.ndarray) -> np.ndarray:
    """chi_ij = Tr(B_ij^dagger S) / d^2."""
    d2 = s.shape[0]
    return np.einsum("ijkl,kl->ij", _CHI_BASIS.conj(), s) / d2


def superop_from_chi(chi: np.ndarray) -> np.ndarray:
    return np.einsum("ij,ijkl->kl", chi, _CHI_BASIS)


def pauli_probs(chi: np.ndarray) -> dict[str, float]:
    """Pauli-twirled probabilities = real diagonal of chi."""
    return {l: float(chi[k, k].real) for k, l in enumerate(LABELS)}


_NY = np.array([l.count("Y") for l in LABELS])
_YSIGN = (-1.0) ** (_NY[:, None] + _NY[None, :])


def to_hirai_convention(chi: np.ndarray) -> np.ndarray:
    """Hirai's saved chi corresponds to Y -> -Y (sign flip of elements with odd total #Y).

    Diagonal (Pauli-twirled probabilities) is unaffected. Found empirically: after this
    map the two agree to ~1e-7 (Hirai's numerical noise floor).
    """
    return _YSIGN * chi


def ms_ideal_unitary(sign: int = +1) -> np.ndarray:
    """U_ideal = exp(sign * i * pi/4 * XX). Hirai convention: sign=+1."""
    xx = np.kron(X, X)
    return np.cos(np.pi / 4) * np.eye(4) + sign * 1j * np.sin(np.pi / 4) * xx
